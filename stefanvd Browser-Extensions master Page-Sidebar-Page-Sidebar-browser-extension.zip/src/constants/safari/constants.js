/* eslint-disable no-unused-vars */
const exbrowser = "safari";
// values: "chrome", "safari", "edge", "firefox", "opera", "yandex", "whale"
const linkredirectionoptions = "https://stefanvd.net/project/rotate-that-video-player/browser/options/";
const linkdeveloperwebsite = "https://www.stefanvd.net";
const linkproduct = "https://chromewebstore.google.com/detail/" + chrome.runtime.id;
const linkdonate = "https://www.stefanvd.net/donate/";
const writereview = "https://chromewebstore.google.com/detail/" + chrome.runtime.id + "/reviews";
const linkchangelog = "https://stefanvd.net/project/rotate-that-video-player/browser/google-chrome/changelog/";
const linktranslate = "https://www.stefanvd.net/project/translate/";
const linksupport = "https://www.stefanvd.net/support/";
const linkwelcome = "https://stefanvd.net/project/rotate-that-video-player/browser/google-chrome/welcome/";
const linkuninstall = "https://stefanvd.net/project/rotate-that-video-player/browser/google-chrome/uninstall/";
const linkguide = "https://stefanvd.net/project/rotate-that-video-player/browser/google-chrome/guide/";
const linkproductdescription = "https://stefanvd.net/project/rotate-that-video-player/browser-extension/";
const browsernewtab = "chrome://newtab/";
const browserstore = "https://chrome.google.com";
const linkyoutube = "https://www.youtube.com/@stefanvandamme?sub_confirmation=1";
const devmode = true;
const devdonate = false;