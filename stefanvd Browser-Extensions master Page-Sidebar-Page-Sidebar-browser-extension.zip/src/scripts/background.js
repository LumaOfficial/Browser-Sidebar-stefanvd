//================================================
/*

Page Sidebar
Effortlessly open any website in your web browser's sidebar – streamline your workflow instantly!
Copyright (C) 2025 Stefan vd
www.stefanvd.net

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.


To view a copy of this license, visit http://creativecommons.org/licenses/GPL/2.0/

*/
//================================================

// Importing the constants
// Execute if importScripts is support such as Google Chrome and not Firefox
if(typeof importScripts !== "undefined"){
	// eslint-disable-next-line no-undef
	importScripts("constants.js");
}

// Function to check if the current browser is Firefox
function isFirefox(){
	return typeof browser !== "undefined" && typeof browser.sidebarAction !== "undefined";
}

// Function to check if the current browser is support chrome.sidePanel
function isChromePanel(){
	return typeof chrome !== "undefined" && typeof chrome.sidePanel !== "undefined";
}

if(isChromePanel()){
	chrome.sidePanel.setPanelBehavior({openPanelOnActionClick: true}).catch((error) => console.error(error));
}

// Execute Firefox-specific code
if(isFirefox()){
	browser.action.onClicked.addListener(function(){
		browser.sidebarAction.toggle();
	});
}

// --- General code
chrome.runtime.onMessage.addListener(function request(request, sender, response){
	// eye protection & autodim & shortcut
	switch(request.name){
	case"bckreload":
		installation();
		break;
	case"sidepanelopen":
		// Chrome uses chrome.sidePanel API, Opera uses opr.sidebarAction API
		if(typeof opr !== "undefined" && typeof opr.sidebarAction !== "undefined"){
			// Opera - always allow since it uses a different sidebar mechanism
			response(true);
		}else{
			// Chrome - use documentId to check if it's a sidebar panel
			response(!sender.documentId);
		}
		break;
	case"getallpermissions":
		var result = "";
		chrome.permissions.getAll(function(permissions){
			result = permissions.permissions;
			chrome.tabs.sendMessage(sender.tab.id, {text: "receiveallpermissions", value: result});
		});
		break;
	case"getallhost":
		// --- Begin Firefox
		chrome.permissions.contains({
			origins: ["*://*/*"]
		}, (result) => {
			if(result){
				// The extension has the permissions
				chrome.runtime.sendMessage({text: "receiveallhost", value: result});
			}else{
				// The extension doesn't have the permissions
				chrome.runtime.sendMessage({text: "receiveallhost", value: result});
			}
		});
		break;
		// --- End Firefox
	}
});

chrome.commands.onCommand.addListener(function(command){
	if(command == "toggle-feature-openweb"){
		chrome.tabs.query({
			active: true,
			lastFocusedWindow: true
		}, function(tabs){
			var tab = tabs[0];
			if(tab){
				var currentpage = tab.url;
				// console.log("currentpage= " + currentpage);
				chrome.sidePanel.open({windowId: tab.windowId}, function(){
					// wait when panel is open, then send the message
					setTimeout(function(){
						chrome.runtime.sendMessage({msg: "setpage", value: currentpage});
					}, 500);
				});
			}
		});
	}
});

// contextMenus
function onClickHandler(info, tab){
	if(info.menuItemId == "totlguideemenu"){
		chrome.tabs.create({url: linkguide, active:true});
	}else if(info.menuItemId == "totldevelopmenu"){
		chrome.tabs.create({url: linkdonate, active:true});
	}else if(info.menuItemId == "totlratemenu"){
		chrome.tabs.create({url: writereview, active:true});
	}else if(info.menuItemId == "totlshareemail"){
		var sturnoffthelightemail = "mailto:your@email.com?subject=" + chrome.i18n.getMessage("sharetexta") + "&body=" + chrome.i18n.getMessage("sharetextb") + " " + linkproduct; chrome.tabs.create({url: sturnoffthelightemail, active:true});
	}else if(info.menuItemId == "totlsharex"){
		var slinkproductcodeurl = encodeURIComponent(chrome.i18n.getMessage("sharetextd") + " " + linkproduct); chrome.tabs.create({url: "https://x.com/intent/tweet?text=" + slinkproductcodeurl, active:true});
	}else if(info.menuItemId == "totlsharefacebook"){
		chrome.tabs.create({url: "https://www.facebook.com/sharer/sharer.php?u=" + linkproduct, active:true});
	}else if(info.menuItemId == "totlsubscribe"){
		chrome.tabs.create({url: linkyoutube, active:true});
	}else if(info.menuItemId == "totlshareqq"){
		chrome.tabs.create({url: "https://connect.qq.com/widget/shareqq/index.html?url=" + encodeURIComponent(linkproduct) + "&title=" + encodeURIComponent(chrome.i18n.getMessage("sharetextd")), active:true});
	}else if(info.menuItemId == "totlshareweibo"){
		chrome.tabs.create({url: "https://service.weibo.com/share/share.php?url=" + linkproduct + "&title=" + encodeURIComponent(chrome.i18n.getMessage("sharetextd")), active:true});
	}else if(info.menuItemId == "totlsharevkontakte"){
		chrome.tabs.create({url: "https://vk.com/share.php?url=" + linkproduct, active:true});
	}else if(info.menuItemId == "totlsharewhatsapp"){
		chrome.tabs.create({url: "https://api.whatsapp.com/send?text=" + chrome.i18n.getMessage("sharetextd") + "%0a" + linkproduct, active:true});
	}else if(info.menuItemId == "totloptions"){
		chrome.runtime.openOptionsPage();
	}else if(info.menuItemId == "sppage"){
		chrome.tabs.query({
			active: true,
			lastFocusedWindow: true
		}, function(tabs){
			var tab = tabs[0];
			if(tab){
				var currentpage = tab.url;
				// console.log("currentpage= " + currentpage);
				if(exbrowser == "opera"){
					// Opera
					setTimeout(function(){
						chrome.runtime.sendMessage({msg: "setpage", value: currentpage});
					}, 500);
				}else if(exbrowser == "firefox"){
					browser.sidebarAction.open();
					setTimeout(function(){
						chrome.runtime.sendMessage({msg: "setpage", value: currentpage});
					}, 500);
				}else{
					// Chromium
					// console.log("currentpage= " + currentpage);
					chrome.sidePanel.open({windowId: tab.windowId}, function(){
						// wait when panel is open, then send the message
						setTimeout(function(){
							chrome.runtime.sendMessage({msg: "setpage", value: currentpage});
						}, 500);
					});
				}
			}
		});
	}else if(info.menuItemId == "snpage"){
		var selectedlink = info.linkUrl;
		console.log("selectedlink= " + selectedlink);
		if(exbrowser == "opera"){
			// wait when panel is open, then send the message
			setTimeout(function(){
				chrome.runtime.sendMessage({msg: "setpage", value: selectedlink});
			}, 500);
		}else if(exbrowser == "firefox"){
			browser.sidebarAction.open();
			setTimeout(function(){
				chrome.runtime.sendMessage({msg: "setpage", value: selectedlink});
			}, 500);
		}else{
			chrome.sidePanel.open({windowId: tab.windowId}, function(){
				// wait when panel is open, then send the message
				setTimeout(function(){
					chrome.runtime.sendMessage({msg: "setpage", value: selectedlink});
				}, 500);
			});
		}
	}else if(info.menuItemId == "slpage"){
		var searchquery = info.selectionText;
		// console.log("searchquery= " + searchquery);
		if(exbrowser == "opera"){
			// wait when panel is open, then send the message
			setTimeout(function(){
				chrome.runtime.sendMessage({msg: "setsearch", value: searchquery});
			}, 500);
		}else if(exbrowser == "firefox"){
			browser.sidebarAction.open();
			setTimeout(function(){
				chrome.runtime.sendMessage({msg: "setpage", value: searchquery});
			}, 500);
		}else{
			chrome.sidePanel.open({windowId: tab.windowId}, function(){
				// wait when panel is open, then send the message
				setTimeout(function(){
					chrome.runtime.sendMessage({msg: "setsearch", value: searchquery});
				}, 500);
			});
		}
	}
}

// check to remove all contextmenus
if(chrome.contextMenus){
	chrome.contextMenus.removeAll(function(){
	// console.log("contextMenus.removeAll callback");
	});
}

var sharemenusharetitle = chrome.i18n.getMessage("sharemenusharetitle");
var sharemenuwelcomeguidetitle = chrome.i18n.getMessage("sharemenuwelcomeguidetitle");
var sharemenutellafriend = chrome.i18n.getMessage("sharemenutellafriend");
var sharemenupostonx = chrome.i18n.getMessage("sharemenupostonx");
var sharemenupostonfacebook = chrome.i18n.getMessage("sharemenupostonfacebook");
// var sharemenuratetitle = chrome.i18n.getMessage("sharemenuratetitle");
var sharemenudonatetitle = chrome.i18n.getMessage("sharemenudonatetitle");
// var sharemenusubscribetitle = chrome.i18n.getMessage("desremyoutube");
var sharemenupostonweibo = chrome.i18n.getMessage("sharemenupostonweibo");
var sharemenupostonvkontakte = chrome.i18n.getMessage("sharemenupostonvkontakte");
var sharemenupostonwhatsapp = chrome.i18n.getMessage("sharemenupostonwhatsapp");
var sharemenupostonqq = chrome.i18n.getMessage("sharemenupostonqq");
var sharemenuoptions = chrome.i18n.getMessage("titelpopupoptions");

function browsercontext(a, b, c, d){
	var item = {"title": a, "type": "normal", "id": b, "contexts": contexts};
	var newitem;
	if(d != ""){
		item = Object.assign({}, item, {parentId: d});
	}
	if(c != ""){
		newitem = Object.assign({}, item, {icons: c});
	}
	try{
		// try show web browsers that do support "icons"
		// Firefox, Opera, Microsoft Edge
		return chrome.contextMenus.create(newitem);
	}catch(e){
		// catch web browsers that do NOT show the icon
		// Google Chrome
		return chrome.contextMenus.create(item);
	}
}

var actionmenuadded = false;
if(chrome.contextMenus){
	if(actionmenuadded == false){
		actionmenuadded = true;

		var contexts = ["action"];

		browsercontext(sharemenuwelcomeguidetitle, "totlguideemenu", {"16": "images/IconGuide.png", "32": "images/IconGuide@2x.png"});
		browsercontext(sharemenudonatetitle, "totldevelopmenu", {"16": "images/IconDonate.png", "32": "images/IconDonate@2x.png"});
		// browsercontext(sharemenuratetitle, "totlratemenu", {"16": "images/IconStar.png", "32": "images/IconStar@2x.png"});

		// Create a parent item and two children.
		var parent = null;
		parent = browsercontext(sharemenusharetitle, "totlsharemenu", {"16": "images/IconShare.png", "32": "images/IconShare@2x.png"});
		browsercontext(sharemenutellafriend, "totlshareemail", {"16": "images/IconEmail.png", "32": "images/IconEmail@2x.png"}, parent);
		chrome.contextMenus.create({"title": "", "type":"separator", "id": "totlsepartorshare", "contexts": contexts, "parentId": parent});

		var uiLanguage = chrome.i18n.getUILanguage();
		if(uiLanguage.includes("zh")){
			// Chinese users
			browsercontext(sharemenupostonweibo, "totlshareweibo", {"16": "images/IconWeibo.png", "32": "images/IconWeibo@2x.png"}, parent);
			browsercontext(sharemenupostonqq, "totlshareqq", {"16": "images/IconQQ.png", "32": "images/IconQQ@2x.png"}, parent);
		}else if(uiLanguage.includes("ru")){
			// Russian users
			browsercontext(sharemenupostonvkontakte, "totlsharevkontakte", {"16": "images/IconVkontakte.png", "32": "images/IconVkontakte@2x.png"}, parent);
			browsercontext(sharemenupostonfacebook, "totlsharefacebook", {"16": "images/IconFacebook.png", "32": "images/IconFacebook@2x.png"}, parent);
			browsercontext(sharemenupostonwhatsapp, "totlsharewhatsapp", {"16": "images/IconWhatsApp.png", "32": "images/IconWhatsApp@2x.png"}, parent);
			browsercontext(sharemenupostonx, "totlsharex", {"16": "images/IconX.png", "32": "images/IconX@2x.png"}, parent);
		}else{
			// all users
			browsercontext(sharemenupostonfacebook, "totlsharefacebook", {"16": "images/IconFacebook.png", "32": "images/IconFacebook@2x.png"}, parent);
			browsercontext(sharemenupostonwhatsapp, "totlsharewhatsapp", {"16": "images/IconWhatsApp.png", "32": "images/IconWhatsApp@2x.png"}, parent);
			browsercontext(sharemenupostonx, "totlsharex", {"16": "images/IconX.png", "32": "images/IconX@2x.png"}, parent);
		}

		// browsercontext(sharemenusubscribetitle, "totlsubscribe", {"16": "images/IconYouTube.png", "32": "images/IconYouTube@2x.png"});

		if(exbrowser == "safari" || exbrowser == "firefox"){
			chrome.contextMenus.create({"title": "", "type":"separator", "id": "totlsepartor", "contexts": contexts});
			browsercontext(sharemenuoptions, "totloptions", {"16": "images/options.png", "32": "images/options@2x.png"});
		}

		chrome.contextMenus.onClicked.addListener(onClickHandler);
	}
}

var contextmenus;
chrome.storage.sync.get(["contextmenus"], function(items){
	contextmenus = items.contextmenus; if(contextmenus == null)contextmenus = true;
	if(contextmenus){ checkcontextmenus(); }
});

// context menu for page and link and selection
var menuitems = null;
var contextmenuadded = false;
var contextarraypage = [];
var contextarraylink = [];
var contextarrayselection = [];

function addwebpagecontext(a, b, c, d){
	var k;
	var addvideolength = b.length;
	for(k = 0; k < addvideolength; k++){
		var contextvideo = b[k];
		menuitems = chrome.contextMenus.create({"title": a, "type":"normal", "id": d, "contexts":[contextvideo]});
		c.push(menuitems);
	}
}

function checkcontextmenus(){
	if(chrome.contextMenus){
		if(contextmenuadded == false){
			contextmenuadded = true;
			// page
			var pagetitle = chrome.i18n.getMessage("pagetitle");
			var contextspage = ["page"];
			addwebpagecontext(pagetitle, contextspage, contextarraypage, "sppage");
			// link
			var linktitle = chrome.i18n.getMessage("linktitle");
			var contextslink = ["link"];
			addwebpagecontext(linktitle, contextslink, contextarraylink, "snpage");
			// selection
			var pagesearchtitle = chrome.i18n.getMessage("pagesearchtitle");
			var contextsselection = ["selection"];
			addwebpagecontext(pagesearchtitle, contextsselection, contextarrayselection, "slpage");
		}
	}
}

function cleanrightclickmenu(menu){
	if(menu.length > 0){
		menu.forEach(function(item){
			if(item != null){ chrome.contextMenus.remove(item); }
		});
	}
	menu.length = 0;
}

function removecontexmenus(){
	if(chrome.contextMenus){
		cleanrightclickmenu(contextarraypage);
		cleanrightclickmenu(contextarraylink);
		cleanrightclickmenu(contextarrayselection);
		contextmenuadded = false;
	}
}

function onchangestorage(a, b, c, d){
	if(a[b]){
		if(a[b].newValue == true){ c(); }else{ d(); }
	}
}

async function getCurrentTab(){
	let queryOptions = {active: true, currentWindow: true};
	let tabs = await chrome.tabs.query(queryOptions);
	return tabs[0];
}

chrome.storage.sync.get(["icon"], function(items){
	if(items["icon"] == undefined){
		if(exbrowser == "safari"){
			items["icon"] = "/images/icon38.png";
		}else{
			items["icon"] = "/images/icon38.png";
		}
	}
	if(chrome.action && typeof chrome.action.setIcon === "function"){
		chrome.action.setIcon({
			path : {
				"19": items["icon"],
				"38": items["icon"]
			}
		});
	}
});

// update on refresh tab
chrome.tabs.onUpdated.addListener(function(){
	getCurrentTab().then((thattab) => {
		chrome.storage.sync.get(["icon"], function(items){
			if(items["icon"] == undefined){
				if(exbrowser == "safari"){
					items["icon"] = "/images/icon38.png";
				}else{
					items["icon"] = "/images/icon38.png";
				}
			}
			if(chrome.action && typeof chrome.action.setIcon === "function"){
				chrome.action.setIcon({tabId : thattab.id, path : {"19": items["icon"], "38": items["icon"]}});
			}
		});
	});
});

chrome.storage.onChanged.addListener(function(changes){
	onchangestorage(changes, "contextmenus", checkcontextmenus, removecontexmenus);
	if(changes["icon"]){
		if(changes["icon"].newValue){
			chrome.tabs.query({}, function(tabs){
				var i, l = tabs.length;
				for(i = 0; i < l; i++){
					if(chrome.action && typeof chrome.action.setIcon === "function"){
						chrome.action.setIcon({tabId : tabs[i].id,
							path : {
								"19": changes["icon"].newValue,
								"38": changes["icon"].newValue
							}
						});
					}
				}
			}
			);
		}
	}
	if(changes["navtop"]){
		if(changes["navtop"].newValue == true){
			chrome.runtime.sendMessage({msg: "setnavtop"});
		}
	}
	if(changes["navbuttons"]){
		if(changes["navbuttons"].newValue == true || changes["navbuttons"].newValue == false){
			chrome.runtime.sendMessage({msg: "setnavbuttons"});
		}
	}
	if(changes["navbottom"]){
		if(changes["navbottom"].newValue == true){
			chrome.runtime.sendMessage({msg: "setnavbottom"});
		}
	}
	if(changes["navhidden"]){
		if(changes["navhidden"].newValue == true){
			chrome.runtime.sendMessage({msg: "setnavhidden"});
		}
	}
	if(changes["searchgoogle"]){
		if(changes["searchgoogle"].newValue == true){
			chrome.runtime.sendMessage({msg: "setrefreshsearch"});
		}
	}
	if(changes["searchbing"]){
		if(changes["searchbing"].newValue == true){
			chrome.runtime.sendMessage({msg: "setrefreshsearch"});
		}
	}
	if(changes["searchduckduckgo"]){
		if(changes["searchduckduckgo"].newValue == true){
			chrome.runtime.sendMessage({msg: "setrefreshsearch"});
		}
	}
	if(changes["searchbaidu"]){
		if(changes["searchbaidu"].newValue == true){
			chrome.runtime.sendMessage({msg: "setrefreshsearch"});
		}
	}
	if(changes["searchyandex"]){
		if(changes["searchyandex"].newValue == true){
			chrome.runtime.sendMessage({msg: "setrefreshsearch"});
		}
	}
	if(changes["searchyahoo"]){
		if(changes["searchyahoo"].newValue == true){
			chrome.runtime.sendMessage({msg: "setrefreshsearch"});
		}
	}
	if(changes["search360"]){
		if(changes["search360"].newValue == true){
			chrome.runtime.sendMessage({msg: "setrefreshsearch"});
		}
	}
	if(changes["searchsogou"]){
		if(changes["searchsogou"].newValue == true){
			chrome.runtime.sendMessage({msg: "setrefreshsearch"});
		}
	}
	if(changes["searchchatgpt"]){
		if(changes["searchchatgpt"].newValue == true){
			chrome.runtime.sendMessage({msg: "setrefreshsearch"});
		}
	}
	if(changes["searchgemini"]){
		if(changes["searchgemini"].newValue == true){
			chrome.runtime.sendMessage({msg: "setrefreshsearch"});
		}
	}
	if(changes["searchwikipedia"]){
		if(changes["searchwikipedia"].newValue == true){
			chrome.runtime.sendMessage({msg: "setrefreshsearch"});
		}
	}
	if(changes["opentab"]){
		if(changes["opentab"].newValue == true || changes["opentab"].newValue == false){
			chrome.runtime.sendMessage({msg: "setopentab"});
		}
	}
	if(changes["opencopy"]){
		if(changes["opencopy"].newValue == true || changes["opencopy"].newValue == false){
			chrome.runtime.sendMessage({msg: "setopencopy"});
		}
	}
	if(changes["gobutton"]){
		if(changes["gobutton"].newValue == true || changes["gobutton"].newValue == false){
			chrome.runtime.sendMessage({msg: "setgobutton"});
		}
	}
	if(changes["opennonebookmarks"]){
		if(changes["opennonebookmarks"].newValue == true){
			chrome.runtime.sendMessage({msg: "setopennonebookmarks"});
		}
	}
	if(changes["openbrowserbookmarks"]){
		if(changes["openbrowserbookmarks"].newValue == true){
			chrome.runtime.sendMessage({msg: "setopenbrowserbookmarks"});
		}
	}
	if(changes["openquickbookmarks"]){
		if(changes["openquickbookmarks"].newValue == true){
			chrome.runtime.sendMessage({msg: "setopenquickbookmarks"});
		}
	}
	if(changes["websitename1"] || changes["websiteurl1"] || changes["websitename2"] || changes["websiteurl2"] || changes["websitename3"] || changes["websiteurl3"] || changes["websitename4"] || changes["websiteurl4"] || changes["websitename5"] || changes["websiteurl5"] || changes["websitename6"] || changes["websiteurl6"] || changes["websitename7"] || changes["websiteurl7"] || changes["websitename8"] || changes["websiteurl8"] || changes["websitename9"] || changes["websiteurl9"] || changes["websitename10"] || changes["websiteurl10"]){
		chrome.runtime.sendMessage({msg: "setbookmarkswebsites"});
	}
	if(changes["googlesidepanel"]){
		if(changes["googlesidepanel"].newValue == true || changes["googlesidepanel"].newValue == false){
			chrome.runtime.sendMessage({msg: "setgooglesidepanel"});
		}
	}
	if(changes["zoom"]){
		if(changes["zoom"].newValue == true || changes["zoom"].newValue == false){
			chrome.runtime.sendMessage({msg: "setzoom"});
		}
	}
	if(changes["step"]){
		chrome.runtime.sendMessage({msg: "setstep"});
	}
	if(changes["defaultzoom"]){
		chrome.runtime.sendMessage({msg: "setdefaultzoom"});
	}
	if(changes["typepanelzone"]){
		if(changes["typepanelzone"].newValue == true){
			chrome.runtime.sendMessage({msg: "settypepanelzone"});
		}
	}
	if(changes["typepanelcustom"]){
		if(changes["typepanelcustom"].newValue == true){
			chrome.runtime.sendMessage({msg: "settypepanelcustom"});
		}
	}
	if(changes["websitestartname"]){
		chrome.runtime.sendMessage({msg: "setwebsitestartname"});
	}
	if(changes["typepanellasttime"]){
		if(changes["typepanellasttime"].newValue == true){
			chrome.runtime.sendMessage({msg: "settypepanellasttime"});
		}
	}
	if(changes["multipletabs"]){
		chrome.runtime.sendMessage({msg: "setmultipletabs"});
	}
	if(changes["typehomezone"]){
		if(changes["typehomezone"].newValue == true){
			chrome.runtime.sendMessage({msg: "settypehomezone"});
		}
	}
	if(changes["typehomecustom"]){
		if(changes["typehomecustom"].newValue == true){
			chrome.runtime.sendMessage({msg: "settypehomecustom"});
		}
	}
	if(changes["websitehomepagename"]){
		chrome.runtime.sendMessage({msg: "setwebsitehomepagename"});
	}
	if(changes["preventclose"]){
		chrome.runtime.sendMessage({msg: "setpreventclose", value: changes["preventclose"].newValue});
	}
	if(changes["dragnewtab"]){
		chrome.runtime.sendMessage({msg: "setdragnewtab", value: changes["dragnewtab"].newValue});
	}
	if(changes["mutetab"]){
		chrome.runtime.sendMessage({msg: "setmutetab", value: changes["mutetab"].newValue});
	}
	if(changes["disablehorizontalscroll"]){
		chrome.runtime.sendMessage({msg: "setdisablehorizontalscroll", value: changes["disablehorizontalscroll"].newValue});
	}
	if(changes["openallnewtab"]){
		chrome.runtime.sendMessage({msg: "setopenallnewtab", value: changes["openallnewtab"].newValue});
	}
	if(changes["autorefresh"]){
		chrome.runtime.sendMessage({msg: "setautorefresh", value: changes["autorefresh"].newValue});
	}
	if(changes["refreshtime"]){
		chrome.runtime.sendMessage({msg: "setrefreshtime", value: changes["refreshtime"].newValue});
	}
	if(changes["showrefreshpanel"]){
		chrome.runtime.sendMessage({msg: "setshowrefreshpanel", value: changes["showrefreshpanel"].newValue});
	}
	if(changes["csp"] || changes["useragent"] || changes["useragentstring"]){
		updateRulesFromStorage();
	}
});

chrome.runtime.setUninstallURL(linkuninstall);

function initwelcome(){
	chrome.storage.sync.get(["firstRun"], function(chromeset){
		if((chromeset["firstRun"] != "false") && (chromeset["firstRun"] != false)){
			chrome.tabs.create({url: linkwelcome});
			var crrinstall = new Date().getTime();
			chrome.storage.sync.set({"firstRun": false, "version": "1.0", "firstDate": crrinstall});
		}
	});
}

// saving group policy values
var savinggroup = {};
function setsavegroup(a, b){
	if(a == true){ savinggroup[b] = true; }else if(a == false){ savinggroup[b] = false; }
}

function readgrouppolicy(items){
	if(chrome.runtime.lastError){
		// console.error("managed error: " + chrome.runtime.lastError.message);
	}else{
		// console.log("items", items);
		if(items.SuppressWelcomePage == true){
			var crrinstall = new Date().getTime();
			chrome.storage.sync.set({"firstRun": false, "version": "1.0", "firstDate": crrinstall});
		}else{
			// no value, then show the page
			initwelcome();
		}

		setsavegroup(items.TypeHomeCustom, "typehomecustom");
		if(items.TypeHomeCustom == true){ savinggroup["typehomezone"] = false; }
		if(items.WebsiteHomepagename != ""){ savinggroup["websitehomepagename"] = items.WebsiteHomepagename; }

		setsavegroup(items.TypePanelCustom, "typepanelcustom");
		if(items.TypePanelCustom == true){ savinggroup["typepanelzone"] = false; }
		if(items.WebsiteStartname != ""){ savinggroup["websitestartname"] = items.WebsiteStartname; }

		setsavegroup(items.SearchGoogle, "searchgoogle");
		setsavegroup(items.SearchGoogleSidepanel, "googlesidepanel");
		setsavegroup(items.ButtonCopyURL, "opencopy");
		setsavegroup(items.ButtonOpenTab, "opentab");
		setsavegroup(items.NoBookmarks, "opennonebookmarks");
		if(items.NoBookmarks == true){ savinggroup["openbrowserbookmarks"] = false; savinggroup["openquickbookmarks"] = false; }
		setsavegroup(items.DisableReminder, "optionskipremember");

		// save total group policy
		chrome.storage.sync.set(savinggroup);
	}
}

var policygrouparray = {};
if(chrome.storage.managed){
	chrome.storage.managed.onChanged.addListener(function(changes){
		// save in memory
		Object.keys(changes).forEach(function(policyName){
			policygrouparray[policyName] = changes[policyName].newValue;
		});

		// update saving group policy values
		var updatesavinggroup = {};

		if(changes["TypeHomeCustom"]){
			updatesavinggroup["typehomecustom"] = changes["TypeHomeCustom"].newValue;
			updatesavinggroup["typehomezone"] = !changes["TypeHomeCustom"].newValue;
		}
		if(changes["WebsiteHomepagename"]){
			updatesavinggroup["websitehomepagename"] = changes["WebsiteHomepagename"].newValue;
		}
		if(changes["TypePanelCustom"]){
			updatesavinggroup["typepanelcustom"] = changes["TypePanelCustom"].newValue;
			updatesavinggroup["typepanelzone"] = !changes["TypePanelCustom"].newValue;
		}
		if(changes["WebsiteStartname"]){
			updatesavinggroup["websitestartname"] = changes["WebsiteStartname"].newValue;
		}
		if(changes["SearchGoogle"]){
			updatesavinggroup["searchgoogle"] = changes["SearchGoogle"].newValue;
		}
		if(changes["SearchGoogleSidepanel"]){
			updatesavinggroup["googlesidepanel"] = changes["SearchGoogleSidepanel"].newValue;
		}
		if(changes["ButtonCopyURL"]){
			updatesavinggroup["opencopy"] = changes["ButtonCopyURL"].newValue;
		}
		if(changes["ButtonOpenTab"]){
			updatesavinggroup["opentab"] = changes["ButtonOpenTab"].newValue;
		}
		if(changes["NoBookmarks"]){
			updatesavinggroup["opennonebookmarks"] = changes["NoBookmarks"].newValue;
			updatesavinggroup["openbrowserbookmarks"] = !changes["NoBookmarks"].newValue;
			updatesavinggroup["openquickbookmarks"] = !changes["NoBookmarks"].newValue;
		}
		if(changes["DisableReminder"]){
			updatesavinggroup["optionskipremember"] = changes["DisableReminder"].newValue;
		}

		// update save total group policy
		chrome.storage.sync.set(updatesavinggroup);
	});
}

function installation(){
	if(chrome.storage.managed && exbrowser != "firefox"){
		chrome.storage.managed.get(function(items){
			readgrouppolicy(items);
			// save in memory
			if(items && typeof items === "object"){
				Object.keys(items).forEach(function(policyName){
					policygrouparray[policyName] = items[policyName];
				});
			}
		});
	}else{
		initwelcome();
	}
}

function createCspRule(removeCSP){
	const responseHeaders = [
		{header: "frame-options", operation: "remove"},
		{header: "x-frame-options", operation: "remove"}
	];
	if(removeCSP){
		responseHeaders.push({header: "content-security-policy", operation: "remove"});
	}
	return{
		id: 1,
		priority: 1,
		action: {
			type: "modifyHeaders",
			responseHeaders
		},
		condition: {
			urlFilter: "|*://*/*",
			initiatorDomains: [chrome.runtime.id],
			resourceTypes: ["sub_frame"]
		}
	};
}

function createUserAgentRule(userAgentString){
	return{
		id: 2,
		priority: 1,
		action: {
			type: "modifyHeaders",
			requestHeaders: [
				{
					header: "user-agent",
					operation: "set",
					value: userAgentString // MUST be a non-empty string
				}
			]
		},
		condition: {
			urlFilter: "|*://*/*",
			initiatorDomains: [chrome.runtime.id],
			resourceTypes: ["sub_frame"]
		}
	};
}

async function updateRulesFromStorage(){
	chrome.storage.sync.get(["csp", "useragent", "useragentstring"], async(data) => {

		// Always validate the UA string
		const uaString = (data.useragentstring || "").trim();

		const cspRule = createCspRule(data.csp ?? true);

		const uaRules = data.useragent && uaString.length > 0 ? [createUserAgentRule(uaString)] : [];

		await chrome.declarativeNetRequest.updateDynamicRules({
			removeRuleIds: [1, 2],
			addRules: [cspRule, ...uaRules]
		});

		if(isChromePanel()){
			chrome.runtime.getContexts({contextTypes: ["SIDE_PANEL"]}, (contexts) => {
				if(contexts && contexts.length > 0){
					// Sidepanel is currently open → refresh it
					// console.log("Sidepanel is open, run action");
					chrome.runtime.sendMessage({msg: "panelrefresh"});
				}else{
					// Sidepanel is closed → do nothing
					// console.log("Sidepanel is not open, skipping refresh");
				}
			});
		}

	});
}

chrome.runtime.onInstalled.addListener(async() => {
	installation();
	updateRulesFromStorage();
});

chrome.runtime.onStartup.addListener(() => {
	updateRulesFromStorage();
});